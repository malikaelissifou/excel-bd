import { useState } from 'react';
import { ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface AddSequenceModalProps {
  open: boolean;
  onClose: () => void;
  headers: string[];
  onComplete: (data: Record<string, any>) => void;
}

export default function AddSequenceModal({ open, onClose, headers, onComplete }: AddSequenceModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<Record<string, any>>({});

  const currentHeader = headers[currentStep];
  const totalSteps = headers.length;

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFinish = () => {
    console.log('✅ Ajout terminé:', formData);
    onComplete(formData);
    handleReset();
  };

  const handleReset = () => {
    setCurrentStep(0);
    setFormData({});
    onClose();
  };

  const handleValueChange = (value: string) => {
    setFormData({
      ...formData,
      [currentHeader]: value,
    });
  };

  const canProceed = () => {
    const value = formData[currentHeader];
    return value !== undefined && value !== null && value !== '';
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && handleReset()}>
      <DialogContent className="sm:max-w-[520px] bg-white border-[#d1d5db] shadow-xl">
        <DialogHeader>
          <DialogTitle className="text-[#1b5e20] tracking-tight">
            Ajouter une ligne &gt; {currentHeader}
          </DialogTitle>
          <DialogDescription className="text-[#6b7280] tracking-tight">
            Saisir la valeur pour <span className="font-medium text-[#374151]">{currentHeader}</span>
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-6">
          <Label htmlFor="field-input" className="text-[#6b7280] mb-2 block tracking-tight">
            &gt; {currentHeader}
          </Label>
          <Input
            id="field-input"
            type="text"
            value={formData[currentHeader] || ''}
            onChange={(e) => handleValueChange(e.target.value)}
            placeholder="Entrer une valeur..."
            className="w-full bg-[#f9fafb] border-[#d1d5db] focus:ring-[#4caf50] focus:border-[#4caf50]"
            autoFocus
          />
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-[#e5e7eb]">
          <div className="text-sm text-[#9ca3af] tracking-tight">
            Étape {currentStep + 1} / {totalSteps}
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={handleBack}
              disabled={currentStep === 0}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#d1d5db] text-[#374151] rounded hover:bg-[#9ca3af] disabled:opacity-40 disabled:cursor-not-allowed transition-all duration-200"
            >
              <ChevronLeft className="w-4 h-4" strokeWidth={1.5} />
              Retour
            </button>
            
            {currentStep < totalSteps - 1 ? (
              <button
                onClick={handleNext}
                disabled={!canProceed()}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#1b5e20] text-white rounded hover:bg-[#2e7d32] disabled:opacity-40 disabled:cursor-not-allowed transition-all duration-200"
              >
                Suivant
                <ChevronRight className="w-4 h-4" strokeWidth={1.5} />
              </button>
            ) : (
              <button
                onClick={handleFinish}
                disabled={!canProceed()}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#00c853] text-white rounded hover:bg-[#4caf50] disabled:opacity-40 disabled:cursor-not-allowed transition-all duration-200"
              >
                <Check className="w-4 h-4" strokeWidth={1.5} />
                Terminer
              </button>
            )}
          </div>
        </div>

        {/* Progress indicator */}
        <div className="flex gap-1 mt-2">
          {Array.from({ length: totalSteps }).map((_, index) => (
            <div
              key={index}
              className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                index <= currentStep ? 'bg-[#00c853]' : 'bg-[#e5e7eb]'
              }`}
            />
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}