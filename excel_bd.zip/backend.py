"""
Backend FastAPI pour gestion multi-tableaux Excel (data/database.xlsx)
VERSION DEBUG - Logs détaillés activés
"""

import os
import re
import threading
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime

import pandas as pd
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict

print("🔧 [DEBUG] Imports OK")

# ============================================================================
# CONFIGURATION
# ============================================================================

DATA_DIR = Path("data")
DATABASE_FILE = DATA_DIR / "database.xlsx"
TEMP_FILE = DATA_DIR / "database_tmp.xlsx"

DEFAULT_HEADERS = [
    "Date (Receipt)",
    "Particulars of Receipt",
    "Receipt No.",
    "Bank (Receipt)",
    "Date (Payment)",
    "Payee",
    "Particulars (Payment)",
    "Folio",
    "P.V. No.",
    "Chq. No.",
    "Bank (Payment)",
    "Health",
    "Education",
    "Local Government"
]

DATA_DIR.mkdir(exist_ok=True)
file_lock = threading.Lock()

print(f"🔧 [DEBUG] Config OK - DATABASE_FILE: {DATABASE_FILE}")

# ============================================================================
# MODELS PYDANTIC
# ============================================================================

class TableCreate(BaseModel):
    region: str
    assembly: str

class RowData(BaseModel):
    row: Dict[str, Any]

class RowUpdate(BaseModel):
    row_index: int
    row: Dict[str, Any]

print("🔧 [DEBUG] Models Pydantic OK")

# ============================================================================
# FASTAPI APP
# ============================================================================

app = FastAPI(title="Multi-Table Excel Manager", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

print("🔧 [DEBUG] FastAPI app créée, CORS activé")

# ============================================================================
# HELPERS
# ============================================================================

def sanitize_sheet_name(region: str, assembly: str) -> str:
    print(f"🔧 [DEBUG] sanitize_sheet_name({region}, {assembly})")
    region_clean = re.sub(r'[\\/*?:\[\]]', '_', region.strip())
    assembly_clean = re.sub(r'[\\/*?:\[\]]', '_', assembly.strip())
    sheet_name = f"{region_clean}_{assembly_clean}"[:31]
    print(f"🔧 [DEBUG] → sheet_name: {sheet_name}")
    return sheet_name

def parse_sheet_name(sheet_name: str) -> Tuple[str, str]:
    print(f"🔧 [DEBUG] parse_sheet_name({sheet_name})")
    parts = sheet_name.split('_', 1)
    result = (parts[0], parts[1]) if len(parts) == 2 else (sheet_name, "")
    print(f"🔧 [DEBUG] → {result}")
    return result

def ensure_database_exists():
    print(f"🔧 [DEBUG] ensure_database_exists() - existe: {DATABASE_FILE.exists()}")
    if not DATABASE_FILE.exists():
        with pd.ExcelWriter(DATABASE_FILE, engine='openpyxl') as writer:
            pd.DataFrame({"info": ["Created by Multi-Table Manager"]}).to_excel(
                writer, sheet_name="__info__", index=False
            )
        print(f"✓ Fichier {DATABASE_FILE} créé")

def get_all_sheets() -> Dict[str, pd.DataFrame]:
    print("🔧 [DEBUG] get_all_sheets()")
    ensure_database_exists()
    try:
        sheets = pd.read_excel(DATABASE_FILE, sheet_name=None, engine='openpyxl')
        filtered = {k: v for k, v in sheets.items() if not k.startswith('__')}
        print(f"🔧 [DEBUG] → {len(filtered)} feuilles chargées")
        return filtered
    except Exception as e:
        print(f"✗ [DEBUG] Erreur get_all_sheets: {e}")
        return {}

def get_sheet(region: str, assembly: str) -> Optional[pd.DataFrame]:
    print(f"🔧 [DEBUG] get_sheet({region}, {assembly})")
    sheet_name = sanitize_sheet_name(region, assembly)
    try:
        df = pd.read_excel(DATABASE_FILE, sheet_name=sheet_name, engine='openpyxl')
        print(f"🔧 [DEBUG] → Feuille chargée: {len(df)} lignes, {len(df.columns)} colonnes")
        return df
    except ValueError:
        print(f"🔧 [DEBUG] → Feuille n'existe pas")
        return None
    except Exception as e:
        print(f"✗ [DEBUG] Erreur get_sheet: {e}")
        return None

def save_sheet(region: str, assembly: str, df: pd.DataFrame):
    print(f"🔧 [DEBUG] save_sheet({region}, {assembly})")
    sheet_name = sanitize_sheet_name(region, assembly)
    
    try:
        with pd.ExcelFile(DATABASE_FILE, engine='openpyxl') as xls:
            existing_sheets = {name: pd.read_excel(xls, name) for name in xls.sheet_names}
        
        existing_sheets[sheet_name] = df
        
        with pd.ExcelWriter(TEMP_FILE, engine='openpyxl') as writer:
            for name, data in existing_sheets.items():
                data.to_excel(writer, sheet_name=name, index=False)
        
        os.replace(TEMP_FILE, DATABASE_FILE)
        print(f"✓ Feuille '{sheet_name}' sauvegardée ({len(df)} lignes)")
        
    except Exception as e:
        print(f"✗ [DEBUG] Erreur save_sheet: {e}")
        if TEMP_FILE.exists():
            TEMP_FILE.unlink()
        raise HTTPException(status_code=500, detail=f"Erreur sauvegarde: {str(e)}")

def delete_sheet(region: str, assembly: str):
    print(f"🔧 [DEBUG] delete_sheet({region}, {assembly})")
    sheet_name = sanitize_sheet_name(region, assembly)
    
    try:
        with pd.ExcelFile(DATABASE_FILE, engine='openpyxl') as xls:
            existing_sheets = {name: pd.read_excel(xls, name) for name in xls.sheet_names}
        
        if sheet_name not in existing_sheets:
            raise HTTPException(status_code=404, detail="Tableau introuvable")
        
        del existing_sheets[sheet_name]
        
        with pd.ExcelWriter(TEMP_FILE, engine='openpyxl') as writer:
            for name, data in existing_sheets.items():
                data.to_excel(writer, sheet_name=name, index=False)
        
        os.replace(TEMP_FILE, DATABASE_FILE)
        print(f"✓ Feuille '{sheet_name}' supprimée")
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"✗ [DEBUG] Erreur delete_sheet: {e}")
        if TEMP_FILE.exists():
            TEMP_FILE.unlink()
        raise HTTPException(status_code=500, detail=f"Erreur suppression: {str(e)}")

def normalize_value(val):
    if pd.isna(val):
        return None
    if isinstance(val, str):
        return val.strip().lower()
    if isinstance(val, (pd.Timestamp, datetime)):
        return val.strftime('%Y-%m-%d')
    return val

def normalize_row(row: Dict[str, Any]) -> tuple:
    return tuple(normalize_value(v) for v in row.values())

def is_duplicate(new_row: Dict[str, Any], df: pd.DataFrame) -> bool:
    if len(df) == 0:
        return False
    
    new_normalized = normalize_row(new_row)
    existing_normalized = set(
        normalize_row(row) 
        for row in df.to_dict(orient='records')
    )
    
    return new_normalized in existing_normalized

print("🔧 [DEBUG] Helpers définis")

# ============================================================================
# ENDPOINTS
# ============================================================================

@app.get("/")
def root():
    print("📍 [DEBUG] Endpoint / appelé")
    return {
        "message": "Multi-Table Excel Manager API",
        "version": "2.0.0",
        "status": "running"
    }

@app.get("/tables")
def list_tables():
    print("📍 [DEBUG] Endpoint /tables appelé")
    try:
        with file_lock:
            sheets = get_all_sheets()
            
            tables = []
            for sheet_name, df in sheets.items():
                region, assembly = parse_sheet_name(sheet_name)
                tables.append({
                    "region": region,
                    "assembly": assembly,
                    "sheet_name": sheet_name,
                    "total_rows": len(df),
                    "total_columns": len(df.columns)
                })
            
            print(f"✓ [DEBUG] {len(tables)} tableaux retournés")
            return {
                "tables": tables,
                "total": len(tables)
            }
    except Exception as e:
        print(f"✗ [DEBUG] Erreur /tables: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/tables")
def create_table(data: TableCreate):
    print(f"📍 [DEBUG] POST /tables - region={data.region}, assembly={data.assembly}")
    try:
        with file_lock:
            existing_df = get_sheet(data.region, data.assembly)
            if existing_df is not None:
                print(f"✗ [DEBUG] Tableau existe déjà")
                raise HTTPException(
                    status_code=409,
                    detail=f"Tableau '{data.region} - {data.assembly}' existe déjà"
                )
            
            df = pd.DataFrame(columns=DEFAULT_HEADERS)
            save_sheet(data.region, data.assembly, df)
            
            print(f"✓ [DEBUG] Tableau créé")
            return {
                "success": True,
                "message": f"Tableau '{data.region} - {data.assembly}' créé",
                "region": data.region,
                "assembly": data.assembly,
                "sheet_name": sanitize_sheet_name(data.region, data.assembly)
            }
    except HTTPException:
        raise
    except Exception as e:
        print(f"✗ [DEBUG] Erreur POST /tables: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/tables/{region}/{assembly}")
def remove_table(region: str, assembly: str):
    print(f"📍 [DEBUG] DELETE /tables/{region}/{assembly}")
    try:
        with file_lock:
            delete_sheet(region, assembly)
            return {
                "success": True,
                "message": f"Tableau '{region} - {assembly}' supprimé"
            }
    except Exception as e:
        print(f"✗ [DEBUG] Erreur DELETE: {e}")
        raise

@app.get("/tables/{region}/{assembly}")
def get_table_data(region: str, assembly: str):
    print(f"📍 [DEBUG] GET /tables/{region}/{assembly}")
    try:
        with file_lock:
            df = get_sheet(region, assembly)
            
            if df is None:
                raise HTTPException(status_code=404, detail="Tableau introuvable")
            
            headers = df.columns.tolist()
            rows = df.where(pd.notna(df), None).to_dict(orient='records')
            
            print(f"✓ [DEBUG] Retour: {len(rows)} lignes, {len(headers)} colonnes")
            return {
                "region": region,
                "assembly": assembly,
                "headers": headers,
                "rows": rows,
                "meta": {
                    "total_rows": len(df),
                    "total_columns": len(headers)
                }
            }
    except HTTPException:
        raise
    except Exception as e:
        print(f"✗ [DEBUG] Erreur GET table: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/tables/{region}/{assembly}")
def get_table_data(region: str, assembly: str):
    print(f"📍 [DEBUG] GET /tables/{region}/{assembly}")
    try:
        with file_lock:
            df = get_sheet(region, assembly)
            
            if df is None:
                raise HTTPException(status_code=404, detail="Tableau introuvable")
            
            headers = df.columns.tolist()
            
            # CORRECTION: Remplacer NaN par None AVANT conversion
            rows = df.replace({pd.NA: None, float('nan'): None}).fillna(value=None).to_dict(orient='records')
            
            print(f"✓ [DEBUG] Retour: {len(rows)} lignes, {len(headers)} colonnes")
            return {
                "region": region,
                "assembly": assembly,
                "headers": headers,
                "rows": rows,
                "meta": {
                    "total_rows": len(df),
                    "total_columns": len(headers)
                }
            }
    except HTTPException:
        raise
    except Exception as e:
        print(f"✗ [DEBUG] Erreur GET table: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/tables/{region}/{assembly}/rows")
def add_table_row(region: str, assembly: str, data: RowData):
    print(f"📍 [DEBUG] POST /tables/{region}/{assembly}/rows")
    try:
        with file_lock:
            df = get_sheet(region, assembly)
            
            if df is None:
                raise HTTPException(status_code=404, detail="Tableau introuvable")
            
            expected_cols = set(df.columns)
            provided_cols = set(data.row.keys())
            
            if expected_cols != provided_cols:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "column_mismatch",
                        "expected": sorted(expected_cols),
                        "found": sorted(provided_cols)
                    }
                )
            
            if is_duplicate(data.row, df):
                return JSONResponse(
                    status_code=409,
                    content={
                        "error": "duplicate",
                        "message": "Cette ligne existe déjà"
                    }
                )
            
            new_row_df = pd.DataFrame([data.row])
            df = pd.concat([df, new_row_df], ignore_index=True)
            save_sheet(region, assembly, df)
            
            print(f"✓ [DEBUG] Ligne ajoutée")
            return {
                "success": True,
                "message": "Ligne ajoutée",
                "row_index": len(df) - 1
            }
    except Exception as e:
        print(f"✗ [DEBUG] Erreur POST row: {e}")
        raise

@app.put("/tables/{region}/{assembly}/rows/{row_index}")
def update_table_row(region: str, assembly: str, row_index: int, data: RowData):
    print(f"📍 [DEBUG] PUT /tables/{region}/{assembly}/rows/{row_index}")
    try:
        with file_lock:
            df = get_sheet(region, assembly)
            
            if df is None:
                raise HTTPException(status_code=404, detail="Tableau introuvable")
            
            if row_index < 0 or row_index >= len(df):
                raise HTTPException(
                    status_code=404,
                    detail=f"Index {row_index} invalide (max: {len(df)-1})"
                )
            
            expected_cols = set(df.columns)
            provided_cols = set(data.row.keys())
            
            if expected_cols != provided_cols:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "column_mismatch",
                        "expected": sorted(expected_cols),
                        "found": sorted(provided_cols)
                    }
                )
            
            for col, val in data.row.items():
                df.at[row_index, col] = val
            
            save_sheet(region, assembly, df)
            
            print(f"✓ [DEBUG] Ligne modifiée")
            return {
                "success": True,
                "message": f"Ligne {row_index} modifiée"
            }
    except Exception as e:
        print(f"✗ [DEBUG] Erreur PUT row: {e}")
        raise

@app.post("/import-excel")
async def import_excel(file: UploadFile = File(...)):
    print(f"📍 [DEBUG] POST /import-excel - {file.filename}")
    
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Format invalide")
    
    with file_lock:
        temp_upload = DATA_DIR / f"upload_tmp_{datetime.now().timestamp()}.xlsx"
        
        try:
            content = await file.read()
            with open(temp_upload, 'wb') as f:
                f.write(content)
            
            uploaded_sheets = pd.read_excel(temp_upload, sheet_name=None, engine='openpyxl')
            
            results = {
                "tables_added": 0,
                "tables_merged": 0,
                "rows_added": 0,
                "rows_skipped": 0,
                "errors": []
            }
            
            for sheet_name, uploaded_df in uploaded_sheets.items():
                if sheet_name.startswith('__'):
                    continue
                
                try:
                    region, assembly = parse_sheet_name(sheet_name)
                    uploaded_df.columns = uploaded_df.columns.str.strip()
                    
                    if set(uploaded_df.columns) != set(DEFAULT_HEADERS):
                        results["errors"].append({
                            "sheet": sheet_name,
                            "error": "structure_invalide",
                            "message": f"Structure invalide pour '{sheet_name}'"
                        })
                        continue
                    
                    existing_df = get_sheet(region, assembly)
                    
                    if existing_df is None:
                        save_sheet(region, assembly, uploaded_df)
                        results["tables_added"] += 1
                        results["rows_added"] += len(uploaded_df)
                    else:
                        added = 0
                        skipped = 0
                        
                        for _, row in uploaded_df.iterrows():
                            row_dict = row.to_dict()
                            
                            if is_duplicate(row_dict, existing_df):
                                skipped += 1
                            else:
                                new_row_df = pd.DataFrame([row_dict])
                                existing_df = pd.concat([existing_df, new_row_df], ignore_index=True)
                                added += 1
                        
                        save_sheet(region, assembly, existing_df)
                        results["tables_merged"] += 1
                        results["rows_added"] += added
                        results["rows_skipped"] += skipped
                
                except Exception as e:
                    results["errors"].append({
                        "sheet": sheet_name,
                        "error": "exception",
                        "message": str(e)
                    })
            
            print(f"✓ [DEBUG] Import terminé: {results}")
            return {
                "success": True,
                **results,
                "message": f"{results['tables_added']} créées, {results['tables_merged']} fusionnées"
            }
        
        except Exception as e:
            print(f"✗ [DEBUG] Erreur import: {e}")
            raise HTTPException(status_code=500, detail=str(e))
        finally:
            if temp_upload.exists():
                temp_upload.unlink()

@app.get("/download")
def download():
    print("📍 [DEBUG] GET /download")
    if not DATABASE_FILE.exists():
        raise HTTPException(status_code=404, detail="Base introuvable")
    
    return FileResponse(
        path=DATABASE_FILE,
        filename="database.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

print("✅ [DEBUG] Tous les endpoints définis")
print("🚀 Backend prêt à démarrer")

if __name__ == "__main__":
    import uvicorn
    print("🚀 Démarrage Multi-Table Manager...")
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)